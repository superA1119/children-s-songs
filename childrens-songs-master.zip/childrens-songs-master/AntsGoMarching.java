/**
 * This program sings the song "Ants Go Marching."
 * lyrics: http://kids.niehs.nih.gov/lyrics/antsgo.htm
 *
 * @author  you
 * @version today
 */

public class AntsGoMarching 
{
	/**
	 * Sings the first two lines.
	 *
	 * @param number (as a word) for how the ants march
	 */
	public static void goMarching(String number) 
	{

	}
	
	/**
	 * Sings the third line.
	 *
	 * @param number (as a word) for how the ants march
	 */	
	public static void noHurrah(String number)
	{

	}
	
	/**
	 * Sings the 4th line about the little ant.
	 *
	 * @param action What the little one stops to do
	 */
	public static void littleAnt(String action)
	{	

	}
	
	/**
	 * Sings the last two lines of each verse.
	 */	
	public static void rain() 
	{

	}

	/**
	 * Sings a verse of Ants Go Marching.
	 * 
	 * @param number Number (as a word) for how the ants march
	 * @param action What the little one stops to do
	 */
	public static void singIt(String n, String action) 
	{

		
	}

	/**
	 * Calls the singIt() for each verse.
	 */
	public static void main(String[] args) 
	{
		System.out.println("Ants Go Marching\n");
		
		singIt("one","suck his thumb");
	}
   
}
