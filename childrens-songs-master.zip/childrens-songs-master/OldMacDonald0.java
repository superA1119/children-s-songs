/**
 * This program sings the song Old MacDonald Had a Farm.
 * 
 * @author Jon Cooper
 * @version August 18, 2016 (v0)
 */

public class OldMacDonald0
{
    
    public static void main(String[] args) 
    {
        System.out.println("Old MacDonald Had A Farm\n"); // Give our song a title

        System.out.println("Old MacDonald had a farm, E I E I O.");
        System.out.println("And on that farm he had a duck, E I E I O.");
        System.out.println("With a quack quack here and a quack quack there.");
        System.out.println("Here a quack, there a quack, everywhere a quack, quack.");  
        System.out.println("Old MacDonald had a farm, E I E I O.");
        System.out.println();
        
        System.out.println("Old MacDonald had a farm, E I E I O.");
        System.out.println("And on that farm he had a cow, E I E I O.");
        System.out.println("With a moo moo here and a moo moo there.");
        System.out.println("Here a moo, there a moo, everywhere a moo, moo.");
        System.out.println("Old MacDonald had a farm, E I E I O.");
        System.out.println();

        System.out.println("Old MacDonald had a farm, E I E I O.");
        System.out.println("And on that farm he had a duck, E I E I O.");
        System.out.println("With a quack quack here and a quack quack there.");
        System.out.println("Here a quack, there a moo, everywhere a quack, quack.");
        System.out.println("Old MacDonald had a farm, E I E I O.");
        System.out.println();
    }
    
}
